#!/bin/bash
cd attandancetracker/attandancetracker
exec gunicorn --bind 0.0.0.0:5000 telegrambot:app
