# MITS Attendance Tracker

A Flask web application that tracks student attendance for Madanapalle Institute of Technology & Science (MITS). Students enter their roll number and password, the app fetches live attendance data from the MITS SIMS portal, and provides per-subject analysis with skip/attend recommendations to maintain the 75% threshold. Optionally connects to a Telegram bot for daily 8:30 AM IST attendance alerts.

## Project Structure

```
attandancetracker/
├── attandancetracker/          # Main application source
│   ├── static/                 # Frontend assets (JS, manifest, service worker)
│   ├── templates/              # Flask HTML templates (index.html, admin.html)
│   └── telegrambot.py          # Main Flask app (all routes, scraper, bot, scheduler)
├── requirements.txt
└── pyproject.toml
run.sh                          # Startup script: runs gunicorn from correct directory
```

## Tech Stack

- **Language**: Python 3.12
- **Framework**: Flask
- **Database**: Supabase PostgreSQL via psycopg2 with ThreadedConnectionPool (min=2, max=10)
- **HTTP client**: requests
- **Production server**: gunicorn
- **Scheduler**: APScheduler (daily Telegram updates at 8:30 AM IST)
- **Frontend**: HTML5, Tailwind CSS, Chart.js, jsPDF

## Running the App

The app runs on port 5000 via `run.sh`:
```
bash run.sh
# → cd attandancetracker/attandancetracker && gunicorn --bind 0.0.0.0:5000 telegrambot:app
```

## Environment Variables

- `SUPABASE_DB_PASSWORD` — Supabase DB password (if using Supabase)
- `SUPABASE_DB_HOST`, `SUPABASE_DB_PORT`, `SUPABASE_DB_NAME`, `SUPABASE_DB_USER` — Supabase connection details
- `DATABASE_URL` — Fallback PostgreSQL connection string
- `TELEGRAM_BOT_TOKEN` — Optional; enables Telegram bot functionality
- `SESSION_SECRET` — Optional; Flask session secret key
- `PORT` — Optional; defaults to 5000

## Admin Panel

- URL: `/admin`
- Two-step login: credentials → OTP
- OTP is sent to the Discord webhook (6-digit, 5-minute expiry)
- Login alerts also sent to Discord on every successful admin login
- Passwords are never shown in the admin panel
- Discord webhook: configured in `DISCORD_WEBHOOK` constant in telegrambot.py
- **Notice Board**: Admin can write a scrolling notice and toggle it on/off. When enabled, it appears as a yellow scrolling ticker at the top of the student login page
  - `GET /api/notice` — public endpoint, returns `{active, text}`
  - `GET/POST /api/admin/notice` — admin-only endpoint to read/update notice
  - Settings stored in the `app_settings` DB table

## How It Works

1. Student enters roll number and password
2. The app logs into `mitsims.in` via API
3. Fetches attendance data and parses the response
4. Calculates per-subject attendance percentages
5. Displays analysis showing which classes can be skipped or must be attended to stay above 75%
6. Optionally stores credentials for daily Telegram alerts

## Performance

- DB connections use `psycopg2.pool.ThreadedConnectionPool` (2–10 connections)
- All connections are returned to the pool after each query via `putconn()`
- Connection pool is lazily initialised on first request using double-checked locking

## Deployment

Configured for VM deployment (always-on) to support the background scheduler and Telegram bot:
```
bash run.sh
```
